package com.example.my_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME = "App";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "Foods";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String CALORIE_COL = "calories";

    public DBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT, "
                + CALORIE_COL + " INT)";
        db.execSQL(query);
    }

    public void addFood(String food, int calories){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME_COL, food);
        values.put(CALORIE_COL, calories);
        db.insert(TABLE_NAME, null, values);
    }

    public int getTotalCals(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT SUM(calories) FROM " + TABLE_NAME;
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()){
            return c.getInt(0);
        }
        return 0;
    }

    private int count_rows(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_NAME;
        Cursor c = db.rawQuery(query, null);
        if(c.moveToFirst()){
            return c.getInt(0);
        }
        return 0;
    }

    public ArrayList<String> getData(){
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor c = db.rawQuery(query, null);
        c.moveToFirst();
        while(!c.isAfterLast()) {
            int index = c.getColumnIndex(NAME_COL);
            int index2 = c.getColumnIndex(CALORIE_COL);
            String thisFood = " - ", thisCal = " - ";
            if(index != -1){
                thisFood = c.getString(index);
                thisCal = c.getString(index2);
            }
            list.add(thisFood + " - " + thisCal + " calories"); //add the item
            c.moveToNext();
        }
        c.close();
        return list;
    }

    public void deleteAll(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_NAME;
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

}
