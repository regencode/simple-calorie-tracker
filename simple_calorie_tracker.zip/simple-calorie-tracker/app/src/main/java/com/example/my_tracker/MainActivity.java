package com.example.my_tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    protected DBHandler dbHandler;


    public void setCalories(String cal){
        TextView calorie = (TextView) findViewById(R.id.calorieCounter);
        String currentCalories = calorie.getText().toString();
        calorie.setText(cal);
    }

    private void toInputPage(View view){
        Intent intent = new Intent(MainActivity.this, FoodInput.class);
        TextView calorie = (TextView) findViewById(R.id.calorieCounter);
        String currentCalories = calorie.getText().toString();
        intent.putExtra("curCal", currentCalories);
        startActivity(intent);
    }

    private void toListPage(View view){
        Intent intent = new Intent(MainActivity.this, FoodList.class);
        startActivity(intent);
    }

    private android.view.View.OnClickListener button1click = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            toInputPage(v);
        }
    };
    private android.view.View.OnClickListener button2click = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            toListPage(v);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button updateCalButton = (Button) findViewById(R.id.button);
        Button listButton = (Button) findViewById(R.id.button2);
        updateCalButton.setOnClickListener(button1click);
        listButton.setOnClickListener(button2click);

        dbHandler = new DBHandler(MainActivity.this);
        Integer currentCalories = dbHandler.getTotalCals();
        setCalories(currentCalories.toString());

        Intent intent = getIntent();
        boolean listbool = intent.getBooleanExtra("addListTrue", false);
        if(listbool){

            String food = intent.getStringExtra("addListFood");
            int foodcals = intent.getIntExtra("addListCals", 0);
            dbHandler.addFood(food, foodcals);
            Integer totalCals = dbHandler.getTotalCals();
            setCalories(totalCals.toString());
        }

    }
}