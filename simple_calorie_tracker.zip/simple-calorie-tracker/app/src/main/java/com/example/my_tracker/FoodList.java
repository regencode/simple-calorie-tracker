package com.example.my_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class FoodList extends MainActivity{

    private ListView listView;

    private void toMainPage(View view){
        Intent intent =  new Intent(FoodList.this, MainActivity.class);
        startActivity(intent);
    }

    private void deleteAll(){

    }

    private android.view.View.OnClickListener backClick = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            toMainPage(v);
        }
    };

    private android.view.View.OnClickListener deleteClick = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            dbHandler.deleteAll();
            finish();
            startActivity(getIntent());
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_list);

        Button backButton = (Button) findViewById(R.id.backButton);
        Button deleteButton = (Button) findViewById(R.id.deleteButton);
        backButton.setOnClickListener(backClick);
        deleteButton.setOnClickListener(deleteClick);
        ArrayList<String> foodList = dbHandler.getData();

        listView = (ListView) findViewById(R.id.dbList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.list_item, R.id.text_view, foodList);
        listView.setAdapter(adapter);
    }
}
