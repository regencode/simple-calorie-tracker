package com.example.my_tracker;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;
public class FoodInput extends MainActivity{
    public String currentCalories;
    public void exit(View view){
        Intent intent = new Intent(FoodInput.this, MainActivity.class);
        intent.putExtra("IncrementTrue", true);
        intent.putExtra("increment", Integer.parseInt(currentCalories));
        startActivity(intent);
    }


    private android.view.View.OnClickListener exit = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            exit(v);
        }
    };

    private android.view.View.OnClickListener updateTable = new android.view.View.OnClickListener() {
        public void onClick(View v) {
            EditText food = (EditText) findViewById(R.id.nameField);
            EditText calories = (EditText) findViewById(R.id.calorieField);
            Integer fieldCal = Integer.parseInt(calories.getText().toString());
            Integer curCalInt = Integer.parseInt(currentCalories) + fieldCal;
            Intent intent = new Intent(FoodInput.this, MainActivity.class);
            intent.putExtra("IncrementTrue", true);
            intent.putExtra("increment", curCalInt);
            intent.putExtra("addListTrue", true);
            intent.putExtra("addListFood", food.getText().toString());
            intent.putExtra("addListCals", fieldCal);
            startActivity(intent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_input);

        Button inputButton = (Button) findViewById(R.id.finishinputsButton);
        Button exitButton = (Button) findViewById(R.id.exitButton);
        exitButton.setOnClickListener(exit);
        inputButton.setOnClickListener(updateTable);

        Intent intent = getIntent();
        currentCalories = intent.getStringExtra("curCal");

    }
}
